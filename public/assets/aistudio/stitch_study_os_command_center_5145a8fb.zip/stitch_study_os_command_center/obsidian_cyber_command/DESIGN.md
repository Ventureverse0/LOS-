---
name: Obsidian Cyber Command
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#bcc9cd'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#869397'
  outline-variant: '#3d494c'
  surface-tint: '#4cd7f6'
  primary: '#4cd7f6'
  on-primary: '#003640'
  primary-container: '#06b6d4'
  on-primary-container: '#00424f'
  inverse-primary: '#00687a'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#4edea3'
  on-tertiary: '#003824'
  tertiary-container: '#1bbd85'
  on-tertiary-container: '#00452e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#acedff'
  primary-fixed-dim: '#4cd7f6'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5c'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  display-xl:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-xl-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: -0.01em
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-desktop: 1rem
  margin: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system synthesizes high-velocity developer tooling aesthetics (Linear, Vercel) with the deep modularity and focus of markdown-driven knowledge bases (Obsidian), filtered through a distilled, industrial cyberpunk lens. The experience avoids retro tropes like CRT distortions or neon overload in favor of clinical precision: absolute density, mathematical alignment, and hyper-legibility.

The interface serves technical operators, engineers, and high-cadence builders who demand zero visual friction and high-bandwidth information intake. The visual atmosphere is that of a quiet, ambient telemetry room at midnight—delivering confidence, extreme computational competence, and razor-sharp clarity.

Key stylistic pillars:
- **Clinical Density:** Microscopic margins, hairline structure, and zero decorative fluff. Every pixel represents state, data, or action.
- **Controlled Luminescence:** Neon accents (cyan, amber, emerald) are deployed with surgical restraint, functioning strictly as status indicators, focal paths, and telemetry.
- **Architectural Edge:** Sharp borders, low-contrast bounding boxes, and precision-tooled containers substitute for soft or ambiguous layering.

## Colors

The system uses a strictly dark-mode-first chromatic architecture anchored in deep slate voids with three laser-focused functional accent tiers:

- **Surface System:**
  - `canvas`: `#090D16` (Deep terminal base)
  - `surface-elevated`: `#0F172A` (Panels, modules, toolbars)
  - `surface-overlay`: `#1E293B` (Dropdowns, active states, modals)
  - `border-subtle`: `#334155` (Hairline component separators, inactive grids)
  - `border-strong`: `#475569` (Hover edges, active command focus rings)

- **Chromatics & Functional Accents:**
  - **Primary (Electric Cyan `#06B6D4` / Glow `#22D3EE`):** Module headers, active focus highlights, execution triggers, technical metrics, and data streams.
  - **Secondary (Kinetic Amber `#F59E0B` / Orange `#FB923C`):** Streaks, system alerts, compute load, burn-rates, and time-critical badges.
  - **Tertiary (Quantum Emerald `#10B981`):** Active connections, local daemon operational health, ping parity, and positive telemetry.
  - **Text & Contrast:** Primary text (`#F8FAFC`), Muted text (`#94A3B8`), Dimmed code labels (`#64748B`).

## Typography

Typography establishes an uncompromising technical split: **Geist** delivers crisp, condensed modern sans-serif readability across interface scaffolding and operational commands, while **JetBrains Mono** surfaces all telemetry, numeric quantities, parameters, metadata tags, and execution states.

- **Numbers and Counters:** Must strictly render in `JetBrains Mono` with `tabular-nums` enabled to avoid visual jitter during real-time stream ingestion.
- **Uppercase Usage:** Monospace labels (`label-mono`, `label-mono-sm`) run in full uppercase with expanded letter-spacing (`0.04em`–`0.06em`) to preserve legibility at micro dimensions.
- **Hierarchy:** High data-density interfaces prioritize `body-sm` (13px) and `label-mono` (11px) to maximize viewable context per viewport.

## Layout & Spacing

The system runs on a **modular dock fluid-grid** designed to sustain continuous multi-pane toolsets.

- **Grid Architecture:** Multi-column layout with 12 structural columns on desktop breaking cleanly into 4/6/12 unit modular workspaces. Multi-split viewports adapt smoothly down to 100% full-bleed stack columns on handheld devices.
- **Density Rhythm:** Default component spacing relies strictly on a tight 4px scale (`0.25rem` to `1.25rem`). Gaps between actionable clusters favor `space-xs` and `space-sm` to maintain compact spatial discipline.
- **Responsiveness:**
  - **Desktop (≥1200px):** Multi-pane views (left file/module tree, center command canvas, right telemetry dock). Gutters fixed at `1rem`.
  - **Tablet (768px - 1199px):** Collapsible side modules into floating command palettes.
  - **Mobile (<768px):** Single vertical stream; toolbars dock to bottom sheet controls with `1rem` edge margins.

## Elevation & Depth

Visual hierarchy abandons diffuse soft shadows in favor of **structural containment, luminosity glows, and 1px planar boundaries**.

- **Surface Tiers:**
  - Base: Solid background `#090D16`.
  - Module / Panel: Surface `#0F172A` bound by a solid `1px` border of `#334155`.
  - Floating Toolbars / Popovers: Surface `#1E293B` surrounded by an intensified `1px` border of `#475569`.
- **Cyber Sheen & Border Highlights:**
  Active components, focused inputs, and targeted containers incorporate a subtle radial gradient sheen across their top border (`rgba(6, 182, 212, 0.4)` fading into `transparent`), simulating etched glass illuminated by underlying console hardware.
- **Functional Luminescence:**
  Shadows are utilized exclusively as focused colored blurs:
  - *Primary focus/glow:* `0 0 12px rgba(6, 182, 212, 0.25)`
  - *Streak/critical glow:* `0 0 12px rgba(245, 158, 11, 0.25)`
  - *System active dot:* `0 0 8px rgba(16, 185, 129, 0.5)`

## Shapes

The interface embraces a **Soft-Chiseled geometry (`roundedness: 1`)**.

- Base controls, buttons, tool inputs, and cards use an exact `0.25rem` (4px) corner radius.
- Larger workspace containers, slide-over panels, and system modals utilize `0.5rem` (`rounded-lg`).
- Circular elements are prohibited with the single exception of status LEDs (`w-2 h-2 rounded-full`). Pill shapes are rejected to preserve the clean, engineered silhouette.

## Components

### Buttons
- **Primary Action:** Background `#06B6D4`, label `#090D16` in `Geist Medium`. 1px border `rgba(255, 255, 255, 0.2)`. On hover: `#22D3EE` with `0 0 14px rgba(6, 182, 212, 0.35)`.
- **Secondary / Ghost:** Background `#0F172A`, 1px border `#334155`, text `#F8FAFC`. On hover: border `#475569`, background `#1E293B`.
- **Command / Keybinding Trigger:** Includes monospaced shortcut tokens (`⌘K`, `ESC`) styled with `#64748B` border and `#94A3B8` text.

### Chips & Badges
- Displayed exclusively using `JetBrains Mono` (`label-mono-sm`).
- **Telemetry Chip:** `#0F172A` fill, 1px border `#334155`, text `#94A3B8`.
- **Gamification / Streak Badge:** Border `rgba(245, 158, 11, 0.3)`, background `rgba(245, 158, 11, 0.08)`, text `#FB923C`.
- **Active State Badge:** Leading 6px emerald circle (`#10B981`) paired with uppercase `#10B981` text.

### Input Fields & Command Bars
- Background `#090D16` inset within `#0F172A` modules.
- Border `1px solid #334155`. Caret/cursor in neon cyan (`#22D3EE`).
- Focused state transforms the border to `#06B6D4` with an ambient glow (`box-shadow: 0 0 0 1px #06B6D4, 0 0 10px rgba(6, 182, 212, 0.2)`).

### Cards & Modular Docks
- Pure dark panels (`#0F172A`) segmented by hairline `#334155` borders.
- Header bars feature subtle monospaced breadcrumb markers (e.g., `WORKSPACE // TELEMETRY_01`) in uppercase `#64748B`.
- Top boundary carries a faint 1px linear highlight for simulated backlighting.

### Checkboxes & Toggle Switches
- **Checkbox:** `16px x 16px` square with `2px` radius. Border `#475569`, unchecked background `#090D16`. Checked: `#06B6D4` fill with `#090D16` checkmark icon.
- **Switches:** Rectangular housing (`32px x 18px`), `2px` radius. Active track `#06B6D4`, thumbs are crisp white squares sliding with snap transitions.

### Lists & Tree Views (Obsidian/Linear Inspired)
- Indented file/node hierarchy with 1px structural vertical guide lines (`#1E293B`).
- Active list row: background `#1E293B`, left edge anchored by a 2px vertical neon cyan bar (`#06B6D4`).